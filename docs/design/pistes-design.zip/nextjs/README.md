# Intérimatch — plateforme d'intérim dédiée au BTP

Application Next.js (App Router, React 19) reprenant à l'identique la maquette Intérimatch :
place de marché à deux côtés entre intérimaires du bâtiment et entreprises qui recrutent.

## Démarrer

    npm install
    npm run dev

Ouvrir http://localhost:3000.

Compte de démonstration : bouton **« Utiliser le compte de démonstration »** sur l'écran
d'authentification (remplit e-mail + mot de passe selon le rôle choisi).

## Arborescence

    app/
      layout.js                 police Instrument Sans, providers globaux
      providers.jsx             contexte de session (rôle, auth, profil) + réglages d'accessibilité
      globals.css               reset, variables de couleur, règles d'accessibilité
      page.js                   / — vitrine
      app/page.js               /app — espace connecté
      app/EspaceClient.jsx      routage des onglets selon le rôle
    components/
      Header.jsx                en-tête collant, navigation vitrine / application
      ui/Btn.jsx                bouton avec état de survol
      ui/Box.jsx                conteneur stylé par chaîne CSS
      vitrine/Vitrine.jsx       accroche, problème, parcours, fonctionnalités, entreprises, FAQ, pied
      auth/Auth.jsx             connexion / inscription, sélection du rôle
      auth/AnalyseCV.jsx        étape 2 intérimaire — extraction des compétences du CV
      auth/VerificationSiret.jsx étape 2 entreprise — vérification Sirene
      interimaire/Missions.jsx  recherche, filtres, score de compatibilité, candidature
      interimaire/Profil.jsx    identité, CV numérique, documents, accessibilité
      interimaire/Paie.jsx      heures pointées, acompte, contrat de mission
      entreprise/…              fiches de poste, publication, candidatures
    lib/
      data.js                   données de démonstration (missions, fiches, vivier, documents)
      scoring.js                moteur de matching partagé
      content.js                contenu éditorial de la vitrine
      styles.js                 styles partagés (pill, chip, carte, champ)
      sx.js                     conversion "chaîne CSS" → objet de style React

## Moteur de matching

\`lib/scoring.js\` — un seul moteur pour les deux côtés du marché :

| Critère                        | Poids |
| ------------------------------ | ----- |
| Correspondance des compétences | 38 %  |
| Proximité du chantier          | 24 %  |
| Habilitations détenues         | 22 %  |
| Disponibilité aux dates        | 16 %  |

Une habilitation manquante plafonne son facteur à 0,35 : le candidat reste visible, mais
l'écart apparaît explicitement sous la barre de score.

## Accessibilité

Les réglages (taille de texte S/M/L/XL, contraste renforcé, grandes zones cliquables,
confort de lecture dys, désactivation des animations) sont posés en attributs \`data-*\`
sur \`<html>\` par \`providers.jsx\` et appliqués par \`globals.css\`. Ils sont persistés dans
\`localStorage\` sous la clé \`interimatch.a11y\`.

## Étapes suivantes pour une mise en production

- Authentification réelle (NextAuth / Auth.js), mots de passe hachés avec bcrypt, sessions httpOnly.
- Analyse de CV côté serveur (extraction texte + reconnaissance d'entités métier) via une route \`app/api\`.
- Vérification SIRET sur l'API Sirene de l'INSEE ; offres normalisées depuis l'API France Travail.
- Persistance (PostgreSQL + Prisma) pour les profils, fiches de poste, candidatures et pointages.
- Signature électronique et génération du contrat de mission (mentions obligatoires, art. L1251-12).
