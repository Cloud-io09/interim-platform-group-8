'use client';

import { useState } from 'react';
import { sx } from '@/lib/sx';
import { pill } from '@/lib/styles';
import { useSession } from '@/app/providers';
import Auth from '@/components/auth/Auth';
import Missions from '@/components/interimaire/Missions';
import Profil from '@/components/interimaire/Profil';
import Paie from '@/components/interimaire/Paie';
import EspaceEntreprise, { OngletsEntreprise } from '@/components/entreprise/EspaceEntreprise';

const ONGLETS_INTERIM = [
  { cle: 'missions', label: 'Missions' },
  { cle: 'profil', label: 'Profil & documents' },
  { cle: 'paie', label: 'Paie' },
];

export default function EspaceClient() {
  const { authed, role, compte } = useSession();
  const [ongletInterim, setOngletInterim] = useState('missions');
  const [ongletEntreprise, setOngletEntreprise] = useState('fiches');

  if (!authed) return <Auth />;

  const entreprise = role === 'entreprise';

  return (
    <main style={sx('max-width:1180px;margin:0 auto;padding:24px')}>
      <div style={sx('display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:22px')}>
        <div style={sx('width:42px;height:42px;border-radius:4px;background:#1A1A18;color:#FFFFFF;display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:600')}>
          {compte.initiales}
        </div>
        <div style={sx('margin-right:auto;min-width:0')}>
          <div style={sx('font-size:17px;font-weight:600')}>{compte.nom}</div>
          <div style={sx('font-size:13px;color:#5F5F5A')}>{compte.meta}</div>
        </div>

        {entreprise ? (
          <OngletsEntreprise onglet={ongletEntreprise} setOnglet={setOngletEntreprise} />
        ) : (
          <div style={sx('display:flex;gap:4px;background:#EDEDEA;padding:4px;border-radius:4px')}>
            {ONGLETS_INTERIM.map((o) => (
              <button key={o.cle} type="button" style={sx(pill(ongletInterim === o.cle))} onClick={() => setOngletInterim(o.cle)}>
                {o.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {entreprise ? (
        <EspaceEntreprise onglet={ongletEntreprise} setOnglet={setOngletEntreprise} />
      ) : ongletInterim === 'missions' ? (
        <Missions />
      ) : ongletInterim === 'profil' ? (
        <Profil />
      ) : (
        <Paie />
      )}
    </main>
  );
}
