import Header from '@/components/Header';
import EspaceClient from './EspaceClient';

export const metadata = { title: 'Intérimatch — mon espace' };

export default function PageApplication() {
  return (
    <div style={{ minHeight: '100vh', background: '#F6F6F4' }}>
      <Header />
      <EspaceClient />
    </div>
  );
}
