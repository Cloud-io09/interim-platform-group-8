import { Instrument_Sans } from 'next/font/google';
import { Providers } from './providers';
import './globals.css';

const instrument = Instrument_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-instrument',
  display: 'swap',
});

export const metadata = {
  icons: {
    icon: [
      { url: '/logo/interimatch-favicon-32.png', sizes: '32x32' },
      { url: '/logo/interimatch-favicon-64.png', sizes: '64x64' },
    ],
    apple: '/logo/interimatch-favicon-180.png',
  },
  title: 'Intérimatch — l\u2019intérim du BTP',
  description:
    'Intérimatch — la plateforme d\u2019intérim dédiée au BTP : missions près de chez vous, matching par qualifications, contrat signé en ligne, acompte en 24 h.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr" className={instrument.variable}>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
