import Header from '@/components/Header';
import Vitrine from '@/components/vitrine/Vitrine';

export default function PageAccueil() {
  return (
    <div style={{ minHeight: '100vh', background: '#F6F6F4' }}>
      <Header />
      <Vitrine />
    </div>
  );
}
