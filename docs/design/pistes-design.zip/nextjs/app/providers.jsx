'use client';

import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { PROFIL_DEFAUT } from '@/lib/data';

const SessionCtx = createContext(null);
const A11yCtx = createContext(null);

const A11Y_KEY = 'interimatch.a11y';
const A11Y_DEFAUT = { taille: 'M', contraste: false, gros: false, animations: true, dys: false };
const ECHELLE = { S: 0.94, M: 1, L: 1.12, XL: 1.26 };

export function Providers({ children }) {
  /* ── Session : rôle, authentification, profil issu du CV ── */
  const [role, setRole] = useState('interimaire');
  const [authed, setAuthed] = useState(false);
  const [email, setEmail] = useState('');
  const [profil, setProfil] = useState(PROFIL_DEFAUT);

  const session = useMemo(
    () => ({
      role, setRole, authed, setAuthed, email, setEmail, profil, setProfil,
      deconnexion: () => { setAuthed(false); setEmail(''); },
      compte:
        role === 'entreprise'
          ? { initiales: 'BR', nom: 'Bâtir Rhône SAS', meta: 'Maçonnerie générale · 48 salariés · Lyon 3e' }
          : { initiales: 'KB', nom: 'Karim Benali', meta: 'Maçon coffreur · 6 ans d\u2019expérience · Lyon 7e' },
    }),
    [role, authed, email, profil]
  );

  /* ── Accessibilité : persistée sur l'appareil, appliquée sur <html> ── */
  const [a11y, setA11y] = useState(A11Y_DEFAUT);

  useEffect(() => {
    try {
      const brut = window.localStorage.getItem(A11Y_KEY);
      if (brut) setA11y((prev) => ({ ...prev, ...JSON.parse(brut) }));
    } catch {}
  }, []);

  useEffect(() => {
    const html = document.documentElement;
    const echelle = ECHELLE[a11y.taille] || 1;
    html.style.fontSize = 16 * echelle + 'px';
    html.style.setProperty('--zoom-a11y', String(echelle));
    document.body.style.zoom = echelle === 1 ? '' : String(echelle);
    html.dataset.contraste = String(a11y.contraste);
    html.dataset.gros = String(a11y.gros);
    html.dataset.dys = String(a11y.dys);
    html.dataset.animations = String(a11y.animations);
    try {
      window.localStorage.setItem(A11Y_KEY, JSON.stringify(a11y));
    } catch {}
  }, [a11y]);

  const a11yApi = useMemo(
    () => ({ a11y, setTaille: (taille) => setA11y((p) => ({ ...p, taille })), bascule: (cle) => setA11y((p) => ({ ...p, [cle]: !p[cle] })) }),
    [a11y]
  );

  return (
    <SessionCtx.Provider value={session}>
      <A11yCtx.Provider value={a11yApi}>{children}</A11yCtx.Provider>
    </SessionCtx.Provider>
  );
}

export const useSession = () => useContext(SessionCtx);
export const useA11y = () => useContext(A11yCtx);
