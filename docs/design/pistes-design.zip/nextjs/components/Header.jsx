'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { sx } from '@/lib/sx';
import { pill } from '@/lib/styles';
import { useSession } from '@/app/providers';
import Btn from '@/components/ui/Btn';

export default function Header() {
  const chemin = usePathname();
  const router = useRouter();
  const { authed, deconnexion } = useSession();
  const surApp = chemin.startsWith('/app');

  return (
    <header
      style={sx(
        'position:sticky;top:0;z-index:50;background:rgba(246,246,244,0.92);backdrop-filter:blur(10px);border-bottom:1px solid #E4E4E1'
      )}
    >
      <div style={sx('max-width:1180px;margin:0 auto;padding:14px 24px;display:flex;align-items:center;gap:24px')}>
        <Link href="/" style={sx('display:flex;align-items:center;gap:10px;margin-right:auto;text-decoration:none')}>
          <svg width="26" height="26" viewBox="0 0 132 132" aria-hidden="true" style={{ flex: '0 0 auto' }}>
            <rect x="0" y="0" width="132" height="132" rx="4" fill="#1A1A18" />
            <path d="M28 30 h30 v14 h-16 v44 h16 v14 h-30 z" fill="#F6F6F4" />
            <path d="M104 30 h-30 v14 h16 v44 h-16 v14 h30 z" fill="#F5D90A" />
          </svg>
          <span style={sx('font-size:19px;font-weight:600')}>Intérimatch</span>
          <span style={sx('font-size:11px;font-weight:600;color:#1A1A18;background:#F1F1EE;padding:4px 8px;border-radius:4px')}>
            BTP
          </span>
        </Link>

        <nav style={sx('display:flex;gap:4px;background:#EDEDEA;padding:4px;border-radius:4px')}>
          <Btn css={pill(!surApp)} onClick={() => router.push('/')}>
            Le projet
          </Btn>
          <Btn css={pill(surApp)} onClick={() => router.push('/app')}>
            L&apos;application
          </Btn>
        </nav>

        {authed && (
          <Btn
            css="background:#FFFFFF;border:1px solid #D3D3CF;padding:9px 14px;border-radius:4px;font-size:13px;font-weight:600;font-family:inherit;cursor:pointer;color:#1A1A18;white-space:nowrap"
            hover="border-color:#1A1A18"
            onClick={deconnexion}
          >
            Se déconnecter
          </Btn>
        )}
      </div>
    </header>
  );
}
