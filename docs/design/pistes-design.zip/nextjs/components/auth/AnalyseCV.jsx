'use client';

import { useState } from 'react';
import { sx } from '@/lib/sx';
import { CARD } from '@/lib/styles';
import { CV_ITEMS, CV_FICHIER } from '@/lib/data';
import { useSession } from '@/app/providers';
import Btn from '@/components/ui/Btn';

/** Étape 2 du parcours intérimaire : le CV alimente réellement le profil de matching. */
export default function AnalyseCV() {
  const { setProfil, setAuthed } = useSession();
  const [enCours, setEnCours] = useState(false);
  const [analyse, setAnalyse] = useState(false);
  const [exclus, setExclus] = useState({});

  const retenus = CV_ITEMS.filter((i) => !exclus[i.label]);

  const analyser = () => {
    if (enCours) return;
    setEnCours(true);
    setAnalyse(false);
    // Simule l'extraction serveur (OCR + reconnaissance d'entités métier).
    setTimeout(() => {
      setEnCours(false);
      setAnalyse(true);
    }, 1100);
  };

  const valider = () => {
    setProfil({
      ville: 'Lyon',
      competences: retenus.filter((i) => i.type === 'comp').map((i) => i.label),
      habilitations: retenus.filter((i) => i.type === 'hab').map((i) => i.label),
    });
    setAuthed(true);
  };

  return (
    <section style={sx(CARD + ';padding:34px')}>
      <div style={sx('font-size:13px;font-weight:600;color:#1A1A18;margin-bottom:10px')}>Étape 2 — votre CV</div>
      <h2 style={sx('font-size:22px;line-height:1.2;font-weight:600;margin:0 0 8px')}>
        Déposez votre CV, on remplit le profil
      </h2>
      <p style={sx('font-size:15px;line-height:1.55;color:#5F5F5A;margin:0 0 24px')}>
        L&apos;analyse repère vos métiers, vos compétences chantier et vos habilitations (CACES, AIPR, carte BTP) pour
        préremplir votre profil. Vous validez ensuite chaque élément détecté.
      </p>

      <div style={sx('border:1px solid #E4E4E1;border-radius:4px;padding:18px;display:flex;align-items:center;gap:14px;margin-bottom:16px;background:#FAFAF9')}>
        <div style={sx('width:44px;height:52px;border-radius:4px;background:#FFFFFF;border:1px solid #D3D3CF;display:flex;align-items:flex-end;justify-content:center;padding-bottom:7px;font-size:10px;font-weight:600;color:#B4291F;flex:0 0 auto')}>
          PDF
        </div>
        <div style={sx('min-width:0;flex:1 1 auto')}>
          <div style={sx('font-size:15px;font-weight:600')}>{CV_FICHIER.nom}</div>
          <div style={sx('font-size:13px;color:#5F5F5A')}>{CV_FICHIER.poids} · déposé le {CV_FICHIER.depose}</div>
        </div>
        <span style={sx('font-size:12px;font-weight:600;padding:5px 10px;border-radius:4px;background:#F1F1EE;color:#1A1A18;white-space:nowrap')}>
          Prêt
        </span>
      </div>

      <div style={sx('border:1px dashed #D3D3CF;border-radius:4px;padding:22px;text-align:center;margin-bottom:20px')}>
        <div style={sx('font-size:14px;font-weight:600;margin-bottom:4px')}>Glissez un autre fichier ici</div>
        <div style={sx('font-size:13px;color:#6F6F68')}>PDF, DOC ou DOCX — 5 Mo maximum</div>
      </div>

      <Btn
        css={
          'width:100%;padding:15px;border-radius:4px;font-size:15px;font-weight:600;font-family:inherit;border:0;cursor:' +
          (enCours ? 'progress;' : 'pointer;') +
          (analyse ? 'background:#FFFFFF;border:1px solid #D3D3CF;color:#1A1A18' : 'background:#1A1A18;color:#FFFFFF')
        }
        onClick={analyser}
      >
        {enCours ? 'Analyse du CV en cours…' : analyse ? 'Relancer l\u2019analyse' : 'Analyser mon CV'}
      </Btn>

      {analyse && (
        <div style={sx('margin-top:26px')}>
          <div style={sx('display:flex;align-items:baseline;justify-content:space-between;margin-bottom:14px')}>
            <span style={sx('font-size:13px;font-weight:600;color:#5F5F5A')}>Détecté dans le CV</span>
            <span style={sx('font-size:13px;color:#1A1A18;font-weight:600')}>
              {retenus.length}/{CV_ITEMS.length} retenus
            </span>
          </div>
          <div style={sx('display:flex;flex-wrap:wrap;gap:7px;margin-bottom:22px')}>
            {CV_ITEMS.map((i) => {
              const actif = !exclus[i.label];
              return (
                <Btn
                  key={i.label}
                  css={
                    'padding:8px 12px;border-radius:4px;font-size:13px;font-weight:500;font-family:inherit;cursor:pointer;border:1px solid ' +
                    (actif
                      ? '#1A1A18;background:#1A1A18;color:#FFFFFF'
                      : '#D3D3CF;background:#FFFFFF;color:#6F6F68;text-decoration:line-through')
                  }
                  onClick={() => setExclus((p) => ({ ...p, [i.label]: !p[i.label] }))}
                >
                  {i.label}
                </Btn>
              );
            })}
          </div>
          <div style={sx('background:#FAFAF9;border:1px solid #E4E4E1;border-radius:4px;padding:16px;margin-bottom:20px')}>
            <div style={sx('font-size:13px;font-weight:600;margin-bottom:8px')}>Aussi extrait automatiquement</div>
            <div style={sx('font-size:14px;line-height:1.7;color:#5F5F5A')}>
              Métier principal : maçon coffreur · 6 ans d&apos;expérience · 3 expériences datées · Lyon 7e · permis B
            </div>
          </div>
          <Btn
            css="width:100%;background:#1A1A18;color:#FFFFFF;border:0;padding:16px;border-radius:4px;font-size:16px;font-weight:600;font-family:inherit;cursor:pointer"
            hover="background:#333330"
            onClick={valider}
          >
            Valider et entrer dans mon espace
          </Btn>
          <p style={sx('font-size:13px;color:#6F6F68;margin:14px 0 0')}>
            Cliquez un élément pour l&apos;exclure du profil. Rien n&apos;est publié avant votre validation.
          </p>
        </div>
      )}
    </section>
  );
}
