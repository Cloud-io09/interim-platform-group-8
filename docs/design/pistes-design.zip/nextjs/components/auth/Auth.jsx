'use client';

import { useState } from 'react';
import { sx } from '@/lib/sx';
import { CARD, FIELD, LABEL, roleCard, pill } from '@/lib/styles';
import { useSession } from '@/app/providers';
import Btn from '@/components/ui/Btn';
import AnalyseCV from './AnalyseCV';
import VerificationSiret from './VerificationSiret';

const EMAIL_VALIDE = /^\S+@\S+\.\S+$/;

export default function Auth() {
  const { role, setRole, setAuthed, email, setEmail } = useSession();
  const [mode, setMode] = useState('inscription');
  const [mdp, setMdp] = useState('');
  const [erreur, setErreur] = useState('');

  const entreprise = role === 'entreprise';

  const forceMdp =
    mdp.length === 0
      ? 'Haché avec bcrypt, jamais stocké en clair.'
      : mdp.length < 8
      ? 'Trop court — 8 caractères minimum.'
      : mdp.length < 12
      ? 'Correct. Ajoutez un chiffre et un symbole pour un mot de passe fort.'
      : 'Mot de passe fort.';

  const soumettre = () => {
    if (!EMAIL_VALIDE.test(email)) return setErreur('Adresse e-mail invalide.');
    if (mdp.length < 8) return setErreur('Le mot de passe doit faire au moins 8 caractères.');
    setErreur('');
    if (mode === 'connexion') setAuthed(true);
    // Inscription : l'étape 2 (CV ou SIRET) est la colonne de droite.
  };

  const remplirDemo = () => {
    setEmail(entreprise ? 'contact@batir-rhone.fr' : 'karim.benali@exemple.fr');
    setMdp('chantier2026!');
    setErreur('');
  };

  return (
    <main style={sx('max-width:1180px;margin:0 auto;padding:48px 24px 80px')}>
      <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:24px;align-items:start')}>
        <section style={sx(CARD + ';padding:34px')}>
          <div style={sx('font-size:12px;font-weight:600;color:#6F6F68;margin-bottom:12px')}>Je suis</div>
          <div style={sx('display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:26px')}>
            <Btn css={roleCard(!entreprise)} onClick={() => { setRole('interimaire'); setErreur(''); }}>
              <span style={sx('display:block;font-size:15px;font-weight:600;margin-bottom:3px')}>Intérimaire</span>
              <span style={sx('display:block;font-size:13px;font-weight:400;line-height:1.4')}>Je cherche des missions</span>
            </Btn>
            <Btn css={roleCard(entreprise)} onClick={() => { setRole('entreprise'); setErreur(''); }}>
              <span style={sx('display:block;font-size:15px;font-weight:600;margin-bottom:3px')}>Entreprise</span>
              <span style={sx('display:block;font-size:13px;font-weight:400;line-height:1.4')}>Je publie des fiches de poste</span>
            </Btn>
          </div>

          <div style={sx('display:flex;gap:4px;background:#EDEDEA;padding:4px;border-radius:4px;margin-bottom:26px')}>
            <Btn css={pill(mode === 'connexion')} onClick={() => { setMode('connexion'); setErreur(''); }}>
              J&apos;ai un compte
            </Btn>
            <Btn css={pill(mode === 'inscription')} onClick={() => { setMode('inscription'); setErreur(''); }}>
              Créer un compte
            </Btn>
          </div>

          <h1 style={sx('font-size:28px;line-height:1.15;font-weight:600;margin:0 0 8px')}>
            {mode === 'connexion' ? 'Se connecter' : entreprise ? 'Créer mon compte entreprise' : 'Créer mon compte intérimaire'}
          </h1>
          <p style={sx('font-size:15px;line-height:1.55;color:#5F5F5A;margin:0 0 26px')}>
            {mode === 'connexion'
              ? entreprise
                ? 'Retrouvez vos fiches de poste, vos candidatures et vos contrats.'
                : 'Retrouvez vos missions, vos documents et votre suivi d\u2019heures.'
              : entreprise
              ? 'Étape 1 sur 2 : vos identifiants. Étape 2 : votre SIRET, vérifié auprès de Sirene.'
              : 'Étape 1 sur 2 : vos identifiants. Étape 2 : votre CV, analysé pour préremplir le profil.'}
          </p>

          <label htmlFor="email" style={sx(LABEL)}>Adresse e-mail</label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => { setEmail(e.target.value); setErreur(''); }}
            placeholder="karim.benali@exemple.fr"
            style={sx(FIELD + ';margin-bottom:18px')}
          />

          <label htmlFor="mdp" style={sx(LABEL)}>Mot de passe</label>
          <input
            id="mdp"
            type="password"
            autoComplete="current-password"
            value={mdp}
            onChange={(e) => { setMdp(e.target.value); setErreur(''); }}
            placeholder="8 caractères minimum"
            style={sx(FIELD + ';margin-bottom:8px')}
          />
          <div style={sx('font-size:13px;color:#6F6F68;margin-bottom:20px')}>{forceMdp}</div>

          {erreur && (
            <div role="alert" style={sx('background:#FBEEEC;border:1px solid #EFD2CC;color:#B4291F;font-size:14px;line-height:1.5;padding:13px 15px;border-radius:4px;margin-bottom:18px')}>
              {erreur}
            </div>
          )}

          <Btn
            css="width:100%;background:#1A1A18;color:#FFFFFF;border:0;padding:16px;border-radius:4px;font-size:16px;font-weight:600;font-family:inherit;cursor:pointer"
            hover="background:#333330"
            onClick={soumettre}
          >
            {mode === 'connexion' ? 'Se connecter' : entreprise ? 'Continuer vers mon SIRET' : 'Continuer vers mon CV'}
          </Btn>

          <div style={sx('display:flex;align-items:center;gap:12px;margin:22px 0')}>
            <div style={sx('flex:1;height:1px;background:#E4E4E1')} />
            <span style={sx('font-size:12px;color:#6F6F68')}>ou</span>
            <div style={sx('flex:1;height:1px;background:#E4E4E1')} />
          </div>
          <Btn
            css="width:100%;background:#FFFFFF;border:1px solid #D3D3CF;padding:14px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer;color:#1A1A18"
            hover="border-color:#1A1A18"
            onClick={remplirDemo}
          >
            Utiliser le compte de démonstration
          </Btn>
          <p style={sx('font-size:13px;line-height:1.55;color:#6F6F68;margin:18px 0 0')}>
            Authentification par session chiffrée, mot de passe haché (bcrypt). Aucune donnée revendue à un tiers.
          </p>
        </section>

        {entreprise ? <VerificationSiret /> : <AnalyseCV />}
      </div>
    </main>
  );
}
