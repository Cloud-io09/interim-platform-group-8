'use client';

import { useState } from 'react';
import { sx } from '@/lib/sx';
import { CARD, FIELD, LABEL } from '@/lib/styles';
import { SIRENE_DEMO } from '@/lib/data';
import { useSession } from '@/app/providers';
import Btn from '@/components/ui/Btn';

/** Étape 2 du parcours entreprise : vérification SIRET auprès de la base Sirene. */
export default function VerificationSiret() {
  const { setAuthed } = useSession();
  const [siret, setSiret] = useState('');
  const [enCours, setEnCours] = useState(false);
  const [ok, setOk] = useState(false);

  const verifier = () => {
    if (enCours) return;
    setEnCours(true);
    setOk(false);
    setTimeout(() => {
      setEnCours(false);
      setOk(true);
    }, 900);
  };

  return (
    <section style={sx(CARD + ';padding:34px')}>
      <div style={sx('font-size:13px;font-weight:600;color:#1A1A18;margin-bottom:10px')}>Étape 2 — votre entreprise</div>
      <h2 style={sx('font-size:22px;line-height:1.2;font-weight:600;margin:0 0 8px')}>Un SIRET, et vous publiez</h2>
      <p style={sx('font-size:15px;line-height:1.55;color:#5F5F5A;margin:0 0 24px')}>
        Le SIRET est vérifié auprès de la base Sirene : raison sociale, code NAF et effectif sont récupérés
        automatiquement. Aucune pièce à scanner.
      </p>

      <label htmlFor="siret" style={sx(LABEL)}>Numéro SIRET</label>
      <input
        id="siret"
        type="text"
        value={siret}
        onChange={(e) => setSiret(e.target.value)}
        placeholder="14 chiffres"
        style={sx(FIELD + ';margin-bottom:18px')}
      />
      <Btn
        css={
          'width:100%;padding:15px;border-radius:4px;font-size:15px;font-weight:600;font-family:inherit;border:0;cursor:pointer;' +
          (ok ? 'background:#FFFFFF;border:1px solid #D3D3CF;color:#1A1A18' : 'background:#1A1A18;color:#FFFFFF')
        }
        onClick={verifier}
      >
        {enCours ? 'Vérification auprès de Sirene…' : ok ? 'Vérifier un autre SIRET' : 'Vérifier mon SIRET'}
      </Btn>

      {ok && (
        <div style={sx('margin-top:24px')}>
          <div style={sx('background:#FAFAF9;border:1px solid #E4E4E1;border-radius:4px;padding:20px;margin-bottom:20px')}>
            <div style={sx('font-size:12px;font-weight:600;color:#6F6F68;margin-bottom:14px')}>Récupéré depuis Sirene</div>
            {SIRENE_DEMO(siret).map((i) => (
              <div key={i.label} style={sx('display:flex;gap:16px;align-items:baseline;padding:9px 0')}>
                <span style={sx('font-size:14px;color:#5F5F5A;flex:0 0 120px')}>{i.label}</span>
                <span style={sx('font-size:15px;font-weight:500;min-width:0')}>{i.valeur}</span>
              </div>
            ))}
          </div>
          <Btn
            css="width:100%;background:#1A1A18;color:#FFFFFF;border:0;padding:16px;border-radius:4px;font-size:16px;font-weight:600;font-family:inherit;cursor:pointer"
            hover="background:#333330"
            onClick={() => setAuthed(true)}
          >
            Valider et entrer dans mon espace
          </Btn>
          <p style={sx('font-size:13px;color:#6F6F68;margin:14px 0 0')}>
            Aucun engagement. Vous ne payez qu&apos;à la mission pourvue, sur un coefficient affiché à l&apos;avance.
          </p>
        </div>
      )}
    </section>
  );
}
