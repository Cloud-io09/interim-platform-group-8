'use client';

import { useMemo } from 'react';
import { sx } from '@/lib/sx';
import { CARD, chip } from '@/lib/styles';
import { VIVIER } from '@/lib/data';
import { scoreCandidat } from '@/lib/scoring';
import Btn from '@/components/ui/Btn';

export default function Candidats({ fiches, filtre, setFiltre, decisions, setDecisions }) {
  const parId = useMemo(() => Object.fromEntries(fiches.map((f) => [f.id, f])), [fiches]);

  const liste = useMemo(
    () =>
      VIVIER.filter((c) => parId[c.fiche])
        .filter((c) => filtre === 'Toutes' || parId[c.fiche].titre === filtre)
        .map((c) => {
          const fiche = parId[c.fiche];
          return { ...c, fiche, score: scoreCandidat(c, fiche) };
        })
        .sort((a, b) => b.score - a.score),
    [parId, filtre]
  );

  return (
    <div style={sx('display:flex;flex-direction:column;gap:12px')}>
      <div style={sx('display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:0 2px')}>
        <span style={sx('font-size:20px;font-weight:600;margin-right:auto')}>
          {liste.length} {liste.length > 1 ? 'candidatures' : 'candidature'}
        </span>
        <div style={sx('display:flex;flex-wrap:wrap;gap:7px')}>
          {['Toutes'].concat(fiches.map((f) => f.titre)).map((label) => (
            <Btn key={label} css={chip(filtre === label)} onClick={() => setFiltre(label)}>
              {label}
            </Btn>
          ))}
        </div>
      </div>

      {liste.map((c) => {
        const decision = decisions[c.nom];
        const manque = c.fiche.habs.filter((h) => !c.habs.includes(h));
        const nbComp = c.fiche.comps.filter((x) => c.comps.includes(x)).length;
        const dispoTout = c.dispoJ <= 3;
        return (
          <article key={c.nom} style={sx(CARD + ';padding:28px')}>
            <div style={sx('display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start')}>
              <div style={sx('width:48px;height:48px;border-radius:4px;background:#EDEDEA;color:#5F5F5A;display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:600;flex:0 0 auto')}>
                {c.initiales}
              </div>

              <div style={sx('flex:1 1 260px;min-width:0')}>
                <div style={sx('display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin-bottom:6px')}>
                  <h3 style={sx('font-size:18px;font-weight:600;margin:0')}>{c.nom}</h3>
                  <span
                    style={sx(
                      'font-size:12px;font-weight:600;padding:4px 9px;border-radius:4px;' +
                        (dispoTout ? 'background:#F1F1EE;color:#1A1A18' : 'background:#EDEDEA;color:#5F5F5A')
                    )}
                  >
                    {dispoTout ? 'Disponible tout de suite' : 'Disponible dans ' + c.dispoJ + ' jours'}
                  </span>
                </div>
                <div style={sx('font-size:14px;color:#5F5F5A;margin-bottom:16px')}>
                  {c.metier} · {c.exp} d&apos;expérience · {c.ville} · {c.km} km du chantier
                </div>
                <div style={sx('display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px')}>
                  {c.comps
                    .concat(c.habs)
                    .slice(0, 6)
                    .map((t) => {
                      const attendu = c.fiche.comps.includes(t) || c.fiche.habs.includes(t);
                      return (
                        <span
                          key={t}
                          style={sx(
                            'font-size:12px;font-weight:500;padding:5px 10px;border-radius:4px;' +
                              (attendu ? 'background:#F1F1EE;color:#1A1A18' : 'background:#EDEDEA;color:#5F5F5A')
                          )}
                        >
                          {t}
                        </span>
                      );
                    })}
                </div>
                <div style={sx('font-size:14px;color:#5F5F5A')}>Postule pour : {c.fiche.titre}</div>
              </div>

              <div style={sx('flex:0 1 200px;min-width:180px;display:flex;flex-direction:column;gap:10px')}>
                <div style={sx('border:1px solid #E4E4E1;border-radius:4px;padding:14px')}>
                  <div style={sx('display:flex;align-items:baseline;justify-content:space-between;margin-bottom:9px')}>
                    <span style={sx('font-size:12px;font-weight:600;color:#5F5F5A')}>Score</span>
                    <span style={sx('font-size:18px;font-weight:600;color:#1A1A18')}>{c.score}%</span>
                  </div>
                  <div style={sx('height:7px;border-radius:4px;background:#EDEDEA;overflow:hidden')}>
                    <div style={sx('height:7px;border-radius:4px;background:#F5D90A;width:' + c.score + '%')} />
                  </div>
                  <div style={sx('font-size:12px;color:#6F6F68;margin-top:9px;line-height:1.4')}>
                    {manque.length
                      ? 'Manque : ' + manque.join(', ')
                      : nbComp + '/' + c.fiche.comps.length + ' compétences · habilitations OK'}
                  </div>
                </div>

                <Btn
                  css={
                    'width:100%;padding:13px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer;border:0;' +
                    (decision === 'retenu'
                      ? 'background:#F1F1EE;color:#1A1A18'
                      : decision === 'ecarte'
                      ? 'background:#EDEDEA;color:#6F6F68'
                      : 'background:#1A1A18;color:#FFFFFF')
                  }
                  onClick={() => setDecisions((p) => ({ ...p, [c.nom]: p[c.nom] ? null : 'retenu' }))}
                >
                  {decision === 'retenu' ? 'Retenu — contrat envoyé' : decision === 'ecarte' ? 'Écarté' : 'Proposer la mission'}
                </Btn>

                {!decision && (
                  <Btn
                    css="width:100%;background:transparent;border:0;padding:6px;font-size:13px;font-weight:600;font-family:inherit;cursor:pointer;color:#6F6F68"
                    hover="color:#B4291F"
                    onClick={() => setDecisions((p) => ({ ...p, [c.nom]: 'ecarte' }))}
                  >
                    Écarter la candidature
                  </Btn>
                )}
              </div>
            </div>
          </article>
        );
      })}

      {liste.length === 0 && (
        <div style={sx('background:#FFFFFF;border:1px dashed #D3D3CF;border-radius:4px;padding:48px 24px;text-align:center')}>
          <div style={sx('font-size:17px;font-weight:600;margin-bottom:8px')}>Aucune candidature sur cette fiche</div>
          <div style={sx('font-size:14px;color:#5F5F5A')}>
            Les intérimaires compatibles reçoivent une alerte dès la publication.
          </div>
        </div>
      )}
    </div>
  );
}
