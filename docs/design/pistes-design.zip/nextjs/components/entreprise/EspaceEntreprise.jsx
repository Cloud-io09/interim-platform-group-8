'use client';

import { useMemo, useState } from 'react';
import { sx } from '@/lib/sx';
import { pill } from '@/lib/styles';
import { FICHES_BASE } from '@/lib/data';
import Fiches from './Fiches';
import Publier from './Publier';
import Candidats from './Candidats';

/**
 * Espace entreprise : les fiches publiées vivent ici pour que la publication,
 * la liste et les candidatures partagent le même état.
 */
export default function EspaceEntreprise({ onglet, setOnglet }) {
  const [fichesSup, setFichesSup] = useState([]);
  const [filtreFiche, setFiltreFiche] = useState('Toutes');
  const [decisions, setDecisions] = useState({});

  const fiches = useMemo(() => fichesSup.concat(FICHES_BASE), [fichesSup]);

  const publier = (fiche) => {
    setFichesSup((p) => [fiche, ...p]);
    setOnglet('fiches');
  };

  const voirCandidats = (titre) => {
    setFiltreFiche(titre);
    setOnglet('candidats');
  };

  if (onglet === 'publier') return <Publier onPublier={publier} />;
  if (onglet === 'candidats')
    return (
      <Candidats
        fiches={fiches}
        filtre={filtreFiche}
        setFiltre={setFiltreFiche}
        decisions={decisions}
        setDecisions={setDecisions}
      />
    );
  return <Fiches fiches={fiches} onVoirCandidats={voirCandidats} onPublierClick={() => setOnglet('publier')} />;
}

export function OngletsEntreprise({ onglet, setOnglet }) {
  const items = [
    { cle: 'fiches', label: 'Mes fiches de poste' },
    { cle: 'publier', label: 'Publier une fiche' },
    { cle: 'candidats', label: 'Candidatures' },
  ];
  return (
    <div style={sx('display:flex;gap:4px;background:#EDEDEA;padding:4px;border-radius:4px')}>
      {items.map((i) => (
        <button key={i.cle} type="button" style={sx(pill(onglet === i.cle))} onClick={() => setOnglet(i.cle)}>
          {i.label}
        </button>
      ))}
    </div>
  );
}
