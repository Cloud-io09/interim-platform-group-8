'use client';

import { sx } from '@/lib/sx';
import { CARD } from '@/lib/styles';
import { VIVIER } from '@/lib/data';
import { scoreCandidat, euros } from '@/lib/scoring';
import Btn from '@/components/ui/Btn';

export default function Fiches({ fiches, onVoirCandidats, onPublierClick }) {
  const totalCandidatures = VIVIER.filter((c) => fiches.some((f) => f.id === c.fiche)).length;

  const kpis = [
    { valeur: String(fiches.filter((f) => f.statut === 'ouverte').length), label: 'fiches de poste ouvertes' },
    { valeur: String(totalCandidatures), label: 'candidatures reçues' },
    { valeur: '36 h', label: 'délai moyen pour pourvoir un poste' },
    { valeur: '1,92', label: 'coefficient de facturation affiché' },
  ];

  return (
    <div style={sx('display:flex;flex-direction:column;gap:12px')}>
      <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px')}>
        {kpis.map((k) => (
          <div key={k.label} style={sx(CARD + ';padding:24px')}>
            <div style={sx('font-size:36px;font-weight:600;letter-spacing:-0.02em;line-height:1;margin-bottom:8px')}>{k.valeur}</div>
            <div style={sx('font-size:13px;line-height:1.45;color:#5F5F5A')}>{k.label}</div>
          </div>
        ))}
      </div>

      <div style={sx('display:flex;align-items:baseline;gap:12px;flex-wrap:wrap;margin:14px 2px 0')}>
        <span style={sx('font-size:20px;font-weight:600;margin-right:auto')}>
          {fiches.length} {fiches.length > 1 ? 'fiches de poste' : 'fiche de poste'}
        </span>
        <Btn
          css="background:#1A1A18;color:#FFFFFF;border:0;padding:12px 20px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer;white-space:nowrap"
          hover="background:#333330"
          onClick={onPublierClick}
        >
          Publier une fiche de poste
        </Btn>
      </div>

      {fiches.map((p) => {
        const candidats = VIVIER.filter((c) => c.fiche === p.id);
        const scores = candidats.map((c) => scoreCandidat(c, p));
        const ouverte = p.statut === 'ouverte';
        return (
          <article key={p.id} style={sx(CARD + ';padding:28px')}>
            <div style={sx('display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start')}>
              <div style={sx('flex:1 1 280px;min-width:0')}>
                <div style={sx('display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin-bottom:7px')}>
                  <h3 style={sx('font-size:19px;font-weight:600;margin:0')}>{p.titre}</h3>
                  <span
                    style={sx(
                      'font-size:12px;font-weight:600;padding:5px 10px;border-radius:4px;' +
                        (ouverte ? 'background:#F1F1EE;color:#1A1A18' : 'background:#EDEDEA;color:#5F5F5A')
                    )}
                  >
                    {ouverte ? 'Ouverte' : p.statut === 'pourvue' ? 'Pourvue' : 'Clôturée'}
                  </span>
                </div>
                <div style={sx('font-size:14px;color:#5F5F5A;margin-bottom:18px')}>
                  {p.chantier} · {p.ville} · publiée {p.publiee}
                </div>
                <div style={sx('display:flex;flex-wrap:wrap;gap:7px;margin-bottom:18px')}>
                  {p.comps.concat(p.habs).map((t) => (
                    <span key={t} style={sx('font-size:12px;font-weight:500;padding:6px 11px;border-radius:4px;background:#EDEDEA;color:#5F5F5A')}>
                      {t}
                    </span>
                  ))}
                </div>
                <div style={sx('display:flex;flex-wrap:wrap;gap:24px;font-size:14px;color:#5F5F5A')}>
                  <span>
                    <strong style={sx('color:#1A1A18;font-weight:600')}>{euros(p.taux)}</strong> /h brut
                  </span>
                  <span>{p.dates}</span>
                  <span>{p.duree}</span>
                </div>
              </div>

              <div style={sx('flex:0 1 210px;min-width:190px;display:flex;flex-direction:column;gap:10px')}>
                <div style={sx('border:1px solid #E4E4E1;border-radius:4px;padding:16px')}>
                  <div style={sx('font-size:30px;font-weight:600;letter-spacing:-0.02em;line-height:1;margin-bottom:4px')}>
                    {candidats.length}
                  </div>
                  <div style={sx('font-size:13px;color:#5F5F5A')}>
                    candidatures · meilleur score {(scores.length ? Math.max(...scores) : 0) + '%'}
                  </div>
                </div>
                <Btn
                  css="width:100%;background:#1A1A18;color:#FFFFFF;border:0;padding:13px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer"
                  hover="background:#333330"
                  onClick={() => onVoirCandidats(p.titre)}
                >
                  Voir les candidats
                </Btn>
                <Btn
                  css="width:100%;background:#FFFFFF;border:1px solid #D3D3CF;padding:13px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer;color:#1A1A18"
                  hover="border-color:#1A1A18"
                >
                  {ouverte ? 'Clôturer la fiche' : 'Republier'}
                </Btn>
              </div>
            </div>
          </article>
        );
      })}
    </div>
  );
}
