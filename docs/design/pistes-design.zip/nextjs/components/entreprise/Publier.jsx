'use client';

import { useState } from 'react';
import { sx } from '@/lib/sx';
import { CARD, FIELD, LABEL, chip } from '@/lib/styles';
import { COMPETENCES_REF, HABILITATIONS_REF, MOTIFS_REF, VIVIER } from '@/lib/data';
import { scoreCandidat, euros } from '@/lib/scoring';
import Btn from '@/components/ui/Btn';

const VIDE = {
  titre: '', metier: 'Gros œuvre', chantier: '', ville: '', debut: '2026-10-05',
  duree: '', taux: 16, comps: ['Coffrage banché', 'Ferraillage'], habs: ['Carte BTP'],
  motif: MOTIFS_REF[0], description: '',
};

export default function Publier({ onPublier }) {
  const [f, setF] = useState(VIDE);
  const [erreur, setErreur] = useState('');

  const maj = (champ) => (e) => {
    setF((p) => ({ ...p, [champ]: e.target.value }));
    setErreur('');
  };
  const bascule = (champ, valeur) => () => {
    setF((p) => ({
      ...p,
      [champ]: p[champ].includes(valeur) ? p[champ].filter((x) => x !== valeur) : p[champ].concat(valeur),
    }));
    setErreur('');
  };

  const repereTaux =
    f.taux < 14.5
      ? 'En dessous du marché local — peu de candidats au-delà de 15 km.'
      : f.taux < 17
      ? 'Dans la moyenne du bassin lyonnais pour ce type de poste.'
      : 'Au-dessus du marché — vivier élargi, réponses plus rapides.';

  // Vivier estimé : candidats réels au-dessus de 70 %, complété par la base nationale.
  const vivier = VIVIER.filter((c) => scoreCandidat(c, { comps: f.comps, habs: f.habs }) >= 70).length + 23;

  const publier = () => {
    if (!f.titre.trim()) return setErreur('L\u2019intitulé du poste est obligatoire.');
    if (!f.ville.trim()) return setErreur('Indiquez la commune du chantier.');
    if (!f.duree.trim()) return setErreur('Indiquez la durée de la mission.');
    if (!f.comps.length) return setErreur('Sélectionnez au moins une compétence attendue.');
    onPublier({
      id: 'f' + (Date.now() % 100000),
      titre: f.titre.trim(),
      chantier: f.chantier.trim() || 'Chantier non nommé',
      ville: f.ville.trim(),
      publiee: 'à l\u2019instant',
      taux: f.taux,
      dates: 'à partir du ' + f.debut.split('-').reverse().join('/'),
      duree: f.duree.trim(),
      statut: 'ouverte',
      comps: [...f.comps],
      habs: [...f.habs],
    });
    setF((p) => ({ ...VIDE, comps: p.comps, habs: p.habs, taux: p.taux, metier: p.metier, debut: p.debut }));
    setErreur('');
  };

  return (
    <div style={sx('display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:20px;align-items:start')}>
      <section style={sx(CARD + ';padding:40px')}>
        <h2 style={sx('font-size:24px;font-weight:600;letter-spacing:-0.01em;margin:0 0 8px')}>Nouvelle fiche de poste</h2>
        <p style={sx('font-size:15px;color:#5F5F5A;margin:0 0 36px;max-width:38em')}>
          Cinq champs obligatoires. Plus la fiche est précise, plus le score de compatibilité des candidats est fiable.
        </p>

        <label htmlFor="p-titre" style={sx(LABEL)}>Intitulé du poste</label>
        <input id="p-titre" type="text" value={f.titre} onChange={maj('titre')} placeholder="Maçon coffreur bancheur" style={sx(FIELD + ';margin-bottom:26px')} />

        <div style={sx('font-size:13px;font-weight:600;margin-bottom:10px')}>Corps de métier</div>
        <div style={sx('display:flex;flex-wrap:wrap;gap:7px;margin-bottom:26px')}>
          {['Gros œuvre', 'Second œuvre', 'VRD', 'Engins'].map((m) => (
            <Btn key={m} css={chip(f.metier === m)} onClick={() => setF((p) => ({ ...p, metier: m }))}>
              {m}
            </Btn>
          ))}
        </div>

        <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:20px;margin-bottom:26px')}>
          <div>
            <label htmlFor="p-chantier" style={sx(LABEL)}>Chantier</label>
            <input id="p-chantier" type="text" value={f.chantier} onChange={maj('chantier')} placeholder="Ilot Gerland" style={sx(FIELD)} />
          </div>
          <div>
            <label htmlFor="p-ville" style={sx(LABEL)}>Commune</label>
            <input id="p-ville" type="text" value={f.ville} onChange={maj('ville')} placeholder="Lyon 7e" style={sx(FIELD)} />
          </div>
        </div>

        <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:20px;margin-bottom:26px')}>
          <div>
            <label htmlFor="p-debut" style={sx(LABEL)}>Début de mission</label>
            <input id="p-debut" type="date" value={f.debut} onChange={maj('debut')} style={sx(FIELD + ';padding:13px')} />
          </div>
          <div>
            <label htmlFor="p-duree" style={sx(LABEL)}>Durée</label>
            <input id="p-duree" type="text" value={f.duree} onChange={maj('duree')} placeholder="3 mois renouvelable" style={sx(FIELD)} />
          </div>
        </div>

        <label htmlFor="p-taux" style={sx(LABEL)}>Taux horaire brut — {euros(f.taux)}</label>
        <input
          id="p-taux"
          type="range"
          min={12}
          max={26}
          step={0.1}
          value={f.taux}
          onChange={(e) => setF((p) => ({ ...p, taux: Number(e.target.value) }))}
          style={sx('width:100%;accent-color:#1A1A18;margin-bottom:8px')}
        />
        <div style={sx('font-size:13px;color:#6F6F68;margin-bottom:26px')}>{repereTaux}</div>

        <div style={sx('font-size:13px;font-weight:600;margin-bottom:10px')}>Compétences attendues</div>
        <div style={sx('display:flex;flex-wrap:wrap;gap:7px;margin-bottom:26px')}>
          {COMPETENCES_REF.map((c) => (
            <Btn key={c} css={chip(f.comps.includes(c))} onClick={bascule('comps', c)}>
              {c}
            </Btn>
          ))}
        </div>

        <div style={sx('font-size:13px;font-weight:600;margin-bottom:10px')}>Habilitations exigées</div>
        <div style={sx('display:flex;flex-wrap:wrap;gap:7px;margin-bottom:26px')}>
          {HABILITATIONS_REF.map((h) => (
            <Btn key={h} css={chip(f.habs.includes(h))} onClick={bascule('habs', h)}>
              {h}
            </Btn>
          ))}
        </div>

        <div style={sx('font-size:13px;font-weight:600;margin-bottom:10px')}>Motif de recours</div>
        <div style={sx('display:flex;flex-wrap:wrap;gap:7px;margin-bottom:26px')}>
          {MOTIFS_REF.map((m) => (
            <Btn key={m} css={chip(f.motif === m)} onClick={() => setF((p) => ({ ...p, motif: m }))}>
              {m}
            </Btn>
          ))}
        </div>

        <label htmlFor="p-desc" style={sx(LABEL)}>Description du poste</label>
        <textarea
          id="p-desc"
          rows={4}
          value={f.description}
          onChange={maj('description')}
          placeholder="Coulage de voiles, pose de banches, travail en équipe de 4 sous la conduite du chef de chantier."
          style={sx(FIELD + ';line-height:1.5;resize:vertical;margin-bottom:28px')}
        />

        {erreur && (
          <div role="alert" style={sx('background:#FBEEEC;border:1px solid #EFD2CC;color:#B4291F;font-size:14px;line-height:1.5;padding:13px 15px;border-radius:4px;margin-bottom:18px')}>
            {erreur}
          </div>
        )}

        <div style={sx('display:flex;flex-wrap:wrap;gap:10px;align-items:center')}>
          <Btn
            css="background:#1A1A18;color:#FFFFFF;border:0;padding:16px 26px;border-radius:4px;font-size:16px;font-weight:600;font-family:inherit;cursor:pointer"
            hover="background:#333330"
            onClick={publier}
          >
            Publier la fiche
          </Btn>
          <Btn
            css="background:#FFFFFF;border:1px solid #D3D3CF;padding:16px 22px;border-radius:4px;font-size:15px;font-weight:600;font-family:inherit;cursor:pointer;color:#1A1A18;white-space:nowrap"
            hover="border-color:#1A1A18"
            onClick={() => { setF({ ...VIDE, comps: [], habs: [] }); setErreur(''); }}
          >
            Vider le formulaire
          </Btn>
        </div>
      </section>

      <aside style={sx('position:sticky;top:84px;display:flex;flex-direction:column;gap:12px')}>
        <div style={sx(CARD + ';padding:26px')}>
          <div style={sx('font-size:12px;font-weight:600;color:#6F6F68;margin-bottom:16px')}>Aperçu côté intérimaire</div>
          <div style={sx('font-size:18px;font-weight:600;margin-bottom:5px')}>{f.titre.trim() || 'Intitulé du poste'}</div>
          <div style={sx('font-size:14px;color:#5F5F5A;margin-bottom:16px')}>
            {(f.chantier.trim() || 'Chantier') + ' · ' + (f.ville.trim() || 'Commune') + ' · ' + f.metier}
          </div>
          <div style={sx('display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px')}>
            {f.comps.concat(f.habs).slice(0, 6).map((t) => (
              <span key={t} style={sx('font-size:12px;font-weight:500;padding:6px 10px;border-radius:4px;background:#F1F1EE;color:#1A1A18')}>
                {t}
              </span>
            ))}
          </div>
          <div style={sx('font-size:14px;color:#5F5F5A;line-height:1.6')}>
            {euros(f.taux)} /h brut
            <br />
            {f.duree.trim() || 'Durée à préciser'}
          </div>
        </div>

        <div style={sx(CARD + ';padding:26px')}>
          <div style={sx('font-size:12px;font-weight:600;color:#6F6F68;margin-bottom:14px')}>Vivier correspondant</div>
          <div style={sx('font-size:36px;font-weight:600;letter-spacing:-0.02em;line-height:1;margin-bottom:6px')}>{vivier}</div>
          <div style={sx('font-size:14px;line-height:1.55;color:#5F5F5A')}>
            intérimaires disponibles avec un score supérieur à 70 % pour cette fiche.
          </div>
        </div>

        <div style={sx('background:#1A1A18;color:#DCDCD8;border-radius:4px;padding:26px')}>
          <div style={sx('font-size:12px;font-weight:600;color:#F5D90A;margin-bottom:14px')}>Conformité automatique</div>
          <div style={sx('font-size:14px;line-height:1.65')}>
            Le contrat de mission généré reprendra le motif de recours, le terme précis, la qualification et le taux.
            Durée maximale 18 mois renouvellement compris (art. L1251-12).
          </div>
        </div>
      </aside>
    </div>
  );
}
