'use client';

import { useMemo, useState } from 'react';
import { sx } from '@/lib/sx';
import { CARD, chip } from '@/lib/styles';
import { MISSIONS, METIERS } from '@/lib/data';
import { scoreMission, raisonMission, euros } from '@/lib/scoring';
import { useSession } from '@/app/providers';
import Btn from '@/components/ui/Btn';

export default function Missions() {
  const { profil } = useSession();
  const [q, setQ] = useState('');
  const [metier, setMetier] = useState('Tous');
  const [rayon, setRayon] = useState(40);
  const [tauxMin, setTauxMin] = useState(12);
  const [urgentOnly, setUrgentOnly] = useState(false);
  const [eligibleOnly, setEligibleOnly] = useState(false);
  const [candidatures, setCandidatures] = useState({});

  const reinitialiser = () => {
    setQ('');
    setMetier('Tous');
    setRayon(40);
    setTauxMin(12);
    setUrgentOnly(false);
    setEligibleOnly(false);
  };

  const resultats = useMemo(() => {
    const terme = q.trim().toLowerCase();
    return MISSIONS.map((m) => ({ ...m, score: scoreMission(m, profil) }))
      .filter((m) => m.km <= rayon && m.taux >= tauxMin)
      .filter((m) => metier === 'Tous' || m.metier === metier)
      .filter(
        (m) =>
          !terme ||
          (m.titre + ' ' + m.entreprise + ' ' + m.ville + ' ' + m.comp.join(' ')).toLowerCase().includes(terme)
      )
      .filter((m) => !urgentOnly || m.debut <= 7)
      .filter((m) => !eligibleOnly || m.req.every((r) => profil.habilitations.includes(r)))
      .sort((a, b) => b.score - a.score);
  }, [q, metier, rayon, tauxMin, urgentOnly, eligibleOnly, profil]);

  return (
    <div style={sx('display:flex;flex-wrap:wrap;gap:20px;align-items:flex-start')}>
      <aside style={sx('flex:1 1 240px;min-width:240px;max-width:300px;' + CARD + ';padding:22px')}>
        <div style={sx('font-size:13px;font-weight:600;color:#5F5F5A;margin-bottom:16px')}>Filtres</div>

        <label htmlFor="q" style={sx('display:block;font-size:13px;font-weight:600;margin-bottom:7px')}>Mot-clé</label>
        <input
          id="q"
          type="text"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Coffrage, grue, VRD…"
          style={sx('width:100%;padding:11px 12px;border:1px solid #D3D3CF;border-radius:4px;font-size:14px;font-family:inherit;margin-bottom:20px;background:#FFFFFF;color:#1A1A18')}
        />

        <div style={sx('font-size:13px;font-weight:600;margin-bottom:9px')}>Métier</div>
        <div style={sx('display:flex;flex-wrap:wrap;gap:6px;margin-bottom:20px')}>
          {METIERS.map((m) => (
            <Btn key={m} css={chip(metier === m)} onClick={() => setMetier(m)}>
              {m}
            </Btn>
          ))}
        </div>

        <label htmlFor="rayon" style={sx('display:block;font-size:13px;font-weight:600;margin-bottom:7px')}>
          Rayon : {rayon} km
        </label>
        <input
          id="rayon"
          type="range"
          min={5}
          max={80}
          step={5}
          value={rayon}
          onChange={(e) => setRayon(Number(e.target.value))}
          style={sx('width:100%;accent-color:#1A1A18;margin-bottom:20px')}
        />

        <label htmlFor="taux" style={sx('display:block;font-size:13px;font-weight:600;margin-bottom:7px')}>
          Taux horaire mini : {euros(tauxMin)}
        </label>
        <input
          id="taux"
          type="range"
          min={12}
          max={24}
          step={0.5}
          value={tauxMin}
          onChange={(e) => setTauxMin(Number(e.target.value))}
          style={sx('width:100%;accent-color:#1A1A18;margin-bottom:20px')}
        />

        <label style={sx('display:flex;align-items:center;gap:9px;font-size:14px;cursor:pointer;margin-bottom:8px')}>
          <input
            type="checkbox"
            checked={urgentOnly}
            onChange={() => setUrgentOnly((v) => !v)}
            style={sx('width:17px;height:17px;accent-color:#1A1A18')}
          />
          Démarrage sous 7 jours
        </label>
        <label style={sx('display:flex;align-items:center;gap:9px;font-size:14px;cursor:pointer;margin-bottom:20px')}>
          <input
            type="checkbox"
            checked={eligibleOnly}
            onChange={() => setEligibleOnly((v) => !v)}
            style={sx('width:17px;height:17px;accent-color:#1A1A18')}
          />
          J&apos;ai toutes les habilitations
        </label>

        <Btn
          css="width:100%;background:#FFFFFF;border:1px solid #D3D3CF;padding:11px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer;color:#1A1A18"
          hover="border-color:#1A1A18"
          onClick={reinitialiser}
        >
          Réinitialiser
        </Btn>
      </aside>

      <div style={sx('flex:3 1 420px;min-width:0')}>
        <div style={sx('display:flex;align-items:baseline;gap:10px;margin-bottom:14px;flex-wrap:wrap')}>
          <span style={sx('font-size:20px;font-weight:600')}>
            {resultats.length} {resultats.length > 1 ? 'missions' : 'mission'}
          </span>
          <span style={sx('font-size:14px;color:#5F5F5A;margin-right:auto')}>triées par score de compatibilité</span>
          <span style={sx('font-size:12px;color:#6F6F68')}>Source : API France Travail, normalisée</span>
        </div>

        {resultats.map((m) => {
          const postule = !!candidatures[m.id];
          const urgent = m.debut <= 3;
          return (
            <article key={m.id} style={sx(CARD + ';padding:24px;margin-bottom:12px')}>
              <div style={sx('display:flex;gap:20px;flex-wrap:wrap')}>
                <div style={sx('flex:1 1 260px;min-width:0')}>
                  <div style={sx('display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px')}>
                    <h3 style={sx('font-size:19px;font-weight:600;margin:0')}>{m.titre}</h3>
                    <span
                      style={sx(
                        'font-size:12px;font-weight:600;padding:4px 9px;border-radius:4px;' +
                          (urgent ? 'background:#FBEEEC;color:#B4291F' : 'background:#EDEDEA;color:#5F5F5A')
                      )}
                    >
                      {urgent ? 'Démarrage urgent' : m.metier}
                    </span>
                  </div>
                  <div style={sx('font-size:14px;color:#5F5F5A;margin-bottom:16px')}>
                    {m.entreprise} · {m.ville} · {m.km} km
                  </div>
                  <div style={sx('display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px')}>
                    {m.comp.concat(m.req).map((t) => {
                      const detenu = profil.competences.includes(t) || profil.habilitations.includes(t);
                      return (
                        <span
                          key={t}
                          style={sx(
                            'font-size:12px;font-weight:500;padding:5px 10px;border-radius:4px;' +
                              (detenu
                                ? 'background:#F1F1EE;color:#1A1A18'
                                : 'background:#F6F6F4;color:#7A6A2A;border:1px solid #E4E4E1')
                          )}
                        >
                          {t}
                        </span>
                      );
                    })}
                  </div>
                  <div style={sx('display:flex;flex-wrap:wrap;gap:22px;font-size:14px;color:#5F5F5A')}>
                    <span>
                      <strong style={sx('color:#1A1A18;font-weight:600')}>{euros(m.taux)}</strong> /h brut
                    </span>
                    <span>{m.dates}</span>
                    <span>{m.duree}</span>
                  </div>
                </div>

                <div style={sx('flex:1 1 190px;min-width:180px;display:flex;flex-direction:column;gap:12px')}>
                  <div style={sx('border:1px solid #E4E4E1;border-radius:4px;padding:14px')}>
                    <div style={sx('display:flex;align-items:baseline;justify-content:space-between;margin-bottom:9px')}>
                      <span style={sx('font-size:12px;font-weight:600;color:#5F5F5A')}>Compatibilité</span>
                      <span style={sx('font-size:18px;font-weight:600;color:#1A1A18')}>{m.score}%</span>
                    </div>
                    <div style={sx('height:7px;border-radius:4px;background:#EDEDEA;overflow:hidden')}>
                      <div style={sx('height:7px;border-radius:4px;background:#F5D90A;width:' + m.score + '%')} />
                    </div>
                    <div style={sx('font-size:12px;color:#6F6F68;margin-top:9px;line-height:1.4')}>
                      {raisonMission(m, profil)}
                    </div>
                  </div>
                  <Btn
                    css={
                      'width:100%;padding:13px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer;border:0;' +
                      (postule ? 'background:#F1F1EE;color:#1A1A18' : 'background:#1A1A18;color:#FFFFFF')
                    }
                    onClick={() => setCandidatures((p) => ({ ...p, [m.id]: !p[m.id] }))}
                  >
                    {postule ? 'Candidature envoyée' : 'Postuler'}
                  </Btn>
                </div>
              </div>
            </article>
          );
        })}

        {resultats.length === 0 && (
          <div style={sx('background:#FFFFFF;border:1px dashed #D3D3CF;border-radius:4px;padding:48px 24px;text-align:center')}>
            <div style={sx('font-size:17px;font-weight:600;margin-bottom:8px')}>Aucune mission ne correspond</div>
            <div style={sx('font-size:14px;color:#5F5F5A;margin-bottom:20px')}>
              Élargissez le rayon ou baissez le taux horaire minimum.
            </div>
            <Btn
              css="background:#1A1A18;color:#FFFFFF;border:0;padding:12px 22px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer"
              onClick={reinitialiser}
            >
              Réinitialiser les filtres
            </Btn>
          </div>
        )}
      </div>
    </div>
  );
}
