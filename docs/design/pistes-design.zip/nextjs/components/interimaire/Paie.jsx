'use client';

import { useState } from 'react';
import { sx } from '@/lib/sx';
import { CARD } from '@/lib/styles';
import { HEURES } from '@/lib/data';
import Btn from '@/components/ui/Btn';

export default function Paie() {
  const [demande, setDemande] = useState(false);

  return (
    <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px;align-items:start')}>
      <section style={sx(CARD + ';padding:28px')}>
        <h2 style={sx('font-size:18px;font-weight:600;margin:0 0 20px')}>Semaine en cours</h2>
        <div style={sx('display:flex;align-items:baseline;gap:10px;margin-bottom:22px')}>
          <span style={sx('font-size:46px;font-weight:600;letter-spacing:-0.02em;line-height:1')}>39 h</span>
          <span style={sx('font-size:15px;color:#5F5F5A')}>dont 4 h supplémentaires</span>
        </div>
        {HEURES.map((h) => (
          <div key={h.jour} style={sx('display:flex;align-items:center;gap:14px;padding:11px 0;border-top:1px solid #EDEDEA')}>
            <span style={sx('font-size:14px;color:#5F5F5A;width:96px;flex:0 0 auto')}>{h.jour}</span>
            <div style={sx('flex:1 1 auto;height:8px;border-radius:4px;background:#EDEDEA;overflow:hidden')}>
              <div style={sx('height:8px;border-radius:4px;background:#F5D90A;width:' + h.bar)} />
            </div>
            <span style={sx('font-size:14px;font-weight:600;width:46px;text-align:right;flex:0 0 auto')}>{h.total}</span>
          </div>
        ))}
        <div style={sx('font-size:13px;color:#6F6F68;margin-top:18px;line-height:1.5')}>
          Heures pointées sur le chantier Ilot Gerland et validées par le chef d&apos;équipe.
        </div>
      </section>

      <section style={sx('background:#1A1A18;color:#F6F6F4;border-radius:4px;padding:28px')}>
        <h2 style={sx('font-size:18px;font-weight:600;margin:0 0 20px')}>Acompte</h2>
        <div style={sx('font-size:46px;font-weight:600;letter-spacing:-0.02em;line-height:1;margin-bottom:8px')}>
          {demande ? '0 €' : '340 €'}
        </div>
        <div style={sx('font-size:15px;color:#9A9A94;margin-bottom:26px')}>
          disponibles immédiatement sur les heures déjà validées
        </div>
        <Btn
          css={
            'width:100%;padding:15px;border-radius:4px;font-size:15px;font-weight:600;font-family:inherit;cursor:pointer;border:0;' +
            (demande
              ? 'background:#333330;color:#F5D90A;border:1px solid #4A443A'
              : 'background:#F5D90A;color:#1A1A18')
          }
          onClick={() => setDemande((v) => !v)}
        >
          {demande ? 'Demande envoyée — versement sous 24 h' : 'Demander mon acompte'}
        </Btn>
        <div style={sx('font-size:13px;color:#9A9A94;margin-top:16px;line-height:1.55')}>
          Versement sous 24 h ouvrées. Aucun frais. Le solde est réglé à la paie du 5 du mois.
        </div>
        <div style={sx('border-top:1px solid #35352F;margin-top:26px;padding-top:22px')}>
          <div style={sx('font-size:13px;font-weight:600;color:#F5D90A;margin-bottom:14px')}>Contrat de mission</div>
          <div style={sx('font-size:15px;line-height:1.6;color:#DCDCD8')}>
            Ilot Gerland — Bouygues Bâtiment Sud-Est
            <br />
            Signé électroniquement le 8 septembre, 18 h 42.
            <br />
            Durée : 3 mois, renouvelable une fois (max. 18 mois, art. L1251-12).
          </div>
        </div>
      </section>
    </div>
  );
}
