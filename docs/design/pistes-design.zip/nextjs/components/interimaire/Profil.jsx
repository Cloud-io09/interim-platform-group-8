'use client';

import { useState } from 'react';
import { sx } from '@/lib/sx';
import { CARD } from '@/lib/styles';
import { DOCUMENTS, EXPERIENCES } from '@/lib/data';
import { INFOS_BASE, INFOS_SENSIBLES } from '@/lib/content';
import { useSession, useA11y } from '@/app/providers';
import Btn from '@/components/ui/Btn';

const PANNEAU = CARD + ';padding:40px';
const EYEBROW = 'font-size:12px;font-weight:600;color:#6F6F68';
const TITRE = 'font-size:24px;font-weight:600;letter-spacing:-0.01em;margin:0 0 8px';

const VOLETS = [
  { cle: 'identite', label: 'Identité' },
  { cle: 'cv', label: 'CV numérique' },
  { cle: 'documents', label: 'Documents' },
  { cle: 'a11y', label: 'Accessibilité' },
];

const OPTIONS_A11Y = [
  { cle: 'contraste', titre: 'Contraste renforcé', texte: 'Pour la lecture en extérieur, écran au soleil.' },
  { cle: 'gros', titre: 'Grandes zones cliquables', texte: 'Boutons et champs élargis — utilisable avec des gants.' },
  { cle: 'dys', titre: 'Confort de lecture', texte: 'Police et espacement adaptés aux troubles dys.' },
  { cle: 'animations', titre: 'Animations', texte: 'Désactivez les transitions si elles vous gênent.' },
];

const LIBELLE_TAILLE = { S: 'compacte', M: 'standard', L: 'grande', XL: 'très grande' };

export default function Profil() {
  const { email, profil } = useSession();
  const { a11y, setTaille, bascule } = useA11y();
  const [volet, setVolet] = useState('identite');
  const [sensible, setSensible] = useState(false);

  const compteurs = { identite: '', cv: String(profil.competences.length), documents: String(DOCUMENTS.length), a11y: '' };

  return (
    <div style={sx('display:grid;grid-template-columns:minmax(0,244px) minmax(0,1fr);gap:20px;align-items:start')}>
      <aside style={sx('position:sticky;top:84px;display:flex;flex-direction:column;gap:12px')}>
        <div style={sx(CARD + ';padding:24px;text-align:center')}>
          <div style={sx('width:64px;height:64px;border-radius:4px;background:#1A1A18;color:#FFFFFF;display:flex;align-items:center;justify-content:center;font-size:21px;font-weight:600;margin:0 auto 14px')}>
            KB
          </div>
          <div style={sx('font-size:17px;font-weight:600;margin-bottom:4px')}>Karim Benali</div>
          <div style={sx('font-size:13px;color:#5F5F5A;margin-bottom:14px')}>Maçon coffreur · Lyon 7e</div>
          <div style={sx('display:inline-flex;align-items:center;gap:7px;font-size:12px;font-weight:600;color:#1A1A18;background:#F1F1EE;padding:6px 11px;border-radius:4px')}>
            <span style={sx('width:6px;height:6px;border-radius:50%;background:#1A1A18')} />
            Profil vérifié
          </div>
        </div>

        <nav style={sx(CARD + ';padding:8px;display:flex;flex-direction:column;gap:2px')}>
          {VOLETS.map((v) => {
            const actif = volet === v.cle;
            return (
              <Btn
                key={v.cle}
                css={
                  'display:flex;align-items:center;justify-content:space-between;gap:10px;width:100%;text-align:left;padding:13px 14px;border:0;border-radius:4px;font-size:15px;font-weight:600;font-family:inherit;cursor:pointer;' +
                  (actif ? 'background:#1A1A18;color:#FFFFFF' : 'background:transparent;color:#5F5F5A')
                }
                onClick={() => setVolet(v.cle)}
              >
                <span>{v.label}</span>
                <span style={sx('font-size:12px;font-weight:600;color:' + (actif ? '#9A9A94' : '#A3A39D'))}>
                  {compteurs[v.cle]}
                </span>
              </Btn>
            );
          })}
        </nav>
      </aside>

      <div>
        {volet === 'identite' && (
          <section style={sx(PANNEAU)}>
            <h2 style={sx(TITRE)}>Identité</h2>
            <p style={sx('font-size:15px;color:#5F5F5A;margin:0 0 36px')}>
              Ces informations servent à établir votre contrat de mission.
            </p>

            <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:32px 40px;margin-bottom:40px')}>
              {INFOS_BASE(email).map((i) => (
                <div key={i.label}>
                  <div style={sx(EYEBROW + ';margin-bottom:7px')}>{i.label}</div>
                  <div style={sx('font-size:16px;font-weight:500;line-height:1.45')}>{i.valeur}</div>
                </div>
              ))}
            </div>

            <div style={sx('border-top:1px solid #EDEDEA;padding-top:28px')}>
              <Btn
                css="background:transparent;border:0;padding:0;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer;color:#1A1A18"
                onClick={() => setSensible((v) => !v)}
              >
                {sensible ? 'Masquer les données sensibles' : 'Afficher les données sensibles (chiffrées)'}
              </Btn>
              {sensible && (
                <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:28px 40px;margin-top:26px')}>
                  {INFOS_SENSIBLES.map((i) => (
                    <div key={i.label}>
                      <div style={sx(EYEBROW + ';margin-bottom:7px')}>{i.label}</div>
                      <div style={sx('font-size:16px;font-weight:500;line-height:1.45')}>{i.valeur}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div style={sx('border-top:1px solid #EDEDEA;margin-top:32px;padding-top:28px;display:flex;flex-wrap:wrap;gap:10px;align-items:center')}>
              <Btn
                css="background:#1A1A18;color:#FFFFFF;border:0;padding:13px 20px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer"
                hover="background:#333330"
              >
                Modifier
              </Btn>
              <Btn
                css="background:#FFFFFF;border:1px solid #D3D3CF;padding:13px 20px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer;color:#B4291F"
                hover="border-color:#B4291F"
              >
                Supprimer mon compte
              </Btn>
              <span style={sx('font-size:13px;color:#6F6F68;margin-left:auto')}>RGPD, art. 15 à 17</span>
            </div>
          </section>
        )}

        {volet === 'cv' && (
          <div style={sx('display:flex;flex-direction:column;gap:12px')}>
            <section style={sx(PANNEAU)}>
              <h2 style={sx(TITRE)}>CV numérique</h2>
              <p style={sx('font-size:15px;color:#5F5F5A;margin:0 0 34px')}>
                Rempli une fois, envoyé avec chaque candidature.
              </p>
              <div style={sx(EYEBROW + ';margin-bottom:14px')}>Compétences</div>
              <div style={sx('display:flex;flex-wrap:wrap;gap:8px')}>
                {profil.competences.map((c) => (
                  <span key={c} style={sx('font-size:14px;font-weight:500;background:#F1F1EE;color:#1A1A18;padding:9px 14px;border-radius:4px')}>
                    {c}
                  </span>
                ))}
              </div>
            </section>

            <section style={sx(PANNEAU)}>
              <div style={sx(EYEBROW + ';margin-bottom:6px')}>Expériences</div>
              {EXPERIENCES.map((e) => (
                <div key={e.poste} style={sx('padding:22px 0;border-bottom:1px solid #EDEDEA')}>
                  <div style={sx('font-size:17px;font-weight:600;margin-bottom:5px')}>{e.poste}</div>
                  <div style={sx('font-size:14px;color:#5F5F5A')}>{e.detail}</div>
                </div>
              ))}
            </section>

            <section style={sx(PANNEAU + ';display:flex;align-items:center;gap:16px;flex-wrap:wrap')}>
              <span style={sx('width:10px;height:10px;border-radius:50%;background:#1A1A18;flex:0 0 auto')} />
              <div style={sx('min-width:0;flex:1 1 220px')}>
                <div style={sx('font-size:17px;font-weight:600;margin-bottom:4px')}>Disponible dès le 22 septembre</div>
                <div style={sx('font-size:14px;color:#5F5F5A')}>Rayon de 40 km autour de Lyon</div>
              </div>
              <Btn
                css="background:#FFFFFF;border:1px solid #D3D3CF;padding:13px 20px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer;color:#1A1A18"
                hover="border-color:#1A1A18"
              >
                Changer ma disponibilité
              </Btn>
            </section>
          </div>
        )}

        {volet === 'documents' && (
          <div style={sx('display:flex;flex-direction:column;gap:12px')}>
            <section style={sx(PANNEAU)}>
              <h2 style={sx(TITRE)}>Qualifications &amp; documents</h2>
              <p style={sx('font-size:15px;color:#5F5F5A;margin:0 0 20px')}>
                Vérifiés une fois, valables pour toutes les entreprises.
              </p>
              {DOCUMENTS.map((d) => (
                <div key={d.nom} style={sx('display:flex;align-items:center;gap:18px;padding:22px 0;border-top:1px solid #EDEDEA')}>
                  <span
                    style={sx(
                      'width:9px;height:9px;border-radius:50%;flex:0 0 auto;background:' +
                        (d.etat === 'ok' ? '#1A1A18' : d.etat === 'warn' ? '#E0A21C' : '#D3D3CF')
                    )}
                  />
                  <div style={sx('min-width:0;flex:1 1 auto')}>
                    <div style={sx('font-size:17px;font-weight:600;margin-bottom:4px')}>{d.nom}</div>
                    <div style={sx('font-size:14px;color:#5F5F5A')}>{d.detail}</div>
                  </div>
                  <span
                    style={sx(
                      'font-size:12px;font-weight:600;padding:5px 10px;border-radius:4px;white-space:nowrap;' +
                        (d.etat === 'ok'
                          ? 'background:#F1F1EE;color:#1A1A18'
                          : d.etat === 'warn'
                          ? 'background:#FDF8E3;color:#7A6A2A'
                          : 'background:#EDEDEA;color:#5F5F5A')
                    )}
                  >
                    {d.etat === 'ok' ? 'Vérifié' : d.etat === 'warn' ? 'À renouveler' : 'Manquant'}
                  </span>
                </div>
              ))}
            </section>

            <section style={sx('background:#FDF8E3;border:1px solid #EADFA8;border-radius:4px;padding:28px 40px;display:flex;align-items:center;gap:20px;flex-wrap:wrap')}>
              <div style={sx('min-width:0;flex:1 1 240px')}>
                <div style={sx('font-size:16px;font-weight:600;margin-bottom:5px')}>Un document expire bientôt</div>
                <div style={sx('font-size:14px;line-height:1.55;color:#5F5F5A')}>
                  CACES R486 — échéance dans 45 jours. Relance automatique à J-30.
                </div>
              </div>
              <Btn
                css="background:#1A1A18;color:#FFFFFF;border:0;padding:13px 20px;border-radius:4px;font-size:14px;font-weight:600;font-family:inherit;cursor:pointer"
                hover="background:#333330"
              >
                Déposer le nouveau
              </Btn>
            </section>
          </div>
        )}

        {volet === 'a11y' && (
          <div style={sx('display:flex;flex-direction:column;gap:12px')}>
            <section style={sx(PANNEAU)}>
              <h2 style={sx(TITRE)}>Accessibilité</h2>
              <p style={sx('font-size:15px;line-height:1.55;color:#5F5F5A;margin:0 0 36px;max-width:38em')}>
                Appliqué immédiatement, mémorisé sur cet appareil. Plein soleil, poussière et gants : l&apos;interface
                doit suivre.
              </p>
              <div style={sx(EYEBROW + ';margin-bottom:14px')}>
                Taille du texte — {LIBELLE_TAILLE[a11y.taille]}
              </div>
              <div style={sx('display:flex;flex-wrap:wrap;gap:8px')}>
                {['S', 'M', 'L', 'XL'].map((t) => (
                  <Btn
                    key={t}
                    css={
                      'min-width:60px;padding:14px 18px;border-radius:4px;font-size:15px;font-weight:600;font-family:inherit;cursor:pointer;border:1px solid ' +
                      (a11y.taille === t ? '#1A1A18;background:#1A1A18;color:#FFFFFF' : '#D3D3CF;background:#FFFFFF;color:#1A1A18')
                    }
                    aria-pressed={a11y.taille === t}
                    onClick={() => setTaille(t)}
                  >
                    {t}
                  </Btn>
                ))}
              </div>
            </section>

            <section style={sx(CARD + ';padding:16px 40px')}>
              {OPTIONS_A11Y.map((o) => {
                const actif = !!a11y[o.cle];
                return (
                  <div key={o.cle} style={sx('display:flex;align-items:center;gap:24px;padding:24px 0;border-bottom:1px solid #EDEDEA')}>
                    <div style={sx('min-width:0;flex:1 1 auto')}>
                      <div style={sx('font-size:17px;font-weight:600;margin-bottom:4px')}>{o.titre}</div>
                      <div style={sx('font-size:14px;line-height:1.5;color:#5F5F5A')}>{o.texte}</div>
                    </div>
                    <Btn
                      css={
                        'flex:0 0 auto;width:52px;height:30px;border-radius:15px;border:0;padding:3px;cursor:pointer;display:flex;justify-content:' +
                        (actif ? 'flex-end' : 'flex-start') +
                        ';background:' +
                        (actif ? '#1A1A18' : '#D3D3CF')
                      }
                      aria-pressed={actif}
                      aria-label={o.titre}
                      onClick={() => bascule(o.cle)}
                    >
                      <span style={sx('display:block;width:24px;height:24px;border-radius:50%;background:#FFFFFF')} />
                    </Btn>
                  </div>
                );
              })}
            </section>

            <section style={sx(CARD + ';padding:32px 40px')}>
              <div style={sx(EYEBROW + ';margin-bottom:10px')}>Conformité</div>
              <div style={sx('font-size:15px;line-height:1.65;color:#5F5F5A;max-width:44em')}>
                Navigation complète au clavier, libellés associés à chaque champ, contrastes ≥ 4,5:1, zones cliquables de
                44 px minimum. RGAA 4.1 — partiellement conforme.
              </div>
            </section>
          </div>
        )}
      </div>
    </div>
  );
}
