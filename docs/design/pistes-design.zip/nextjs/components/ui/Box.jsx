import { sx } from '@/lib/sx';

/** <Box as="section" css="..."> — même rôle que style={{...}}, en entrée CSS. */
export default function Box({ as: Tag = 'div', css, children, ...rest }) {
  return (
    <Tag style={sx(css)} {...rest}>
      {children}
    </Tag>
  );
}
