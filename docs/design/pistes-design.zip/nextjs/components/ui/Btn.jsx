'use client';

import { useState } from 'react';
import { sx } from '@/lib/sx';

/**
 * Bouton qui accepte ses styles sous forme de chaînes CSS, état de survol inclus
 * (React ne gère pas :hover en style inline).
 */
export default function Btn({ css, hover, children, ...rest }) {
  const [over, setOver] = useState(false);
  return (
    <button
      type="button"
      style={{ ...sx(css), ...(over && hover ? sx(hover) : null) }}
      onMouseEnter={() => setOver(true)}
      onMouseLeave={() => setOver(false)}
      {...rest}
    >
      {children}
    </button>
  );
}
