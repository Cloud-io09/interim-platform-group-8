'use client';

import { useRouter } from 'next/navigation';
import { sx } from '@/lib/sx';
import { CARD } from '@/lib/styles';
import { scoreMission } from '@/lib/scoring';
import { MISSIONS, PROFIL_DEFAUT } from '@/lib/data';
import {
  HERO, HERO_MISSIONS, CHIFFRES, FRICTIONS_INTERIMAIRE, FRICTIONS_ENTREPRISE,
  ETAPES_INTERIMAIRE, ETAPES_ENTREPRISE, FONCTIONNALITES, ARG_ENTREPRISE,
  CHIFFRES_ENTREPRISE, TEMOIGNAGES, FAQ, PIED,
} from '@/lib/content';
import { useSession } from '@/app/providers';
import Btn from '@/components/ui/Btn';

const SECTION = 'max-width:1180px;margin:0 auto;padding:0 24px 76px';
const EYEBROW_SECTION = 'font-size:15px;font-weight:600;color:#1A1A18;margin:0 0 14px';

export default function Vitrine() {
  const router = useRouter();
  const { setRole } = useSession();

  const versInterimaire = () => {
    setRole('interimaire');
    router.push('/app');
  };
  const versEntreprise = () => {
    setRole('entreprise');
    router.push('/app');
  };

  const parId = Object.fromEntries(MISSIONS.map((m) => [m.id, m]));

  return (
    <main>
      {/* ── Accroche ── */}
      <section style={sx('max-width:1180px;margin:0 auto;padding:80px 24px 56px')}>
        <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:56px;align-items:center')}>
          <div>
            <div style={sx('font-size:14px;color:#5F5F5A;margin-bottom:20px')}>{HERO.compteur}</div>
            <h1 style={sx('font-size:clamp(36px,4.6vw,54px);line-height:1.04;letter-spacing:-0.02em;font-weight:600;margin:0 0 20px;text-wrap:balance')}>
              {HERO.titre}
            </h1>
            <p style={sx('font-size:17px;line-height:1.55;color:#5F5F5A;margin:0 0 30px;max-width:34em;text-wrap:pretty')}>
              {HERO.chapeau}
            </p>
            <div style={sx('display:flex;flex-wrap:wrap;gap:12px')}>
              <Btn
                css="background:#1A1A18;color:#FFFFFF;border:0;padding:16px 26px;border-radius:4px;font-size:16px;font-weight:600;font-family:inherit;cursor:pointer"
                hover="background:#333330"
                onClick={versInterimaire}
              >
                Trouver une mission
              </Btn>
              <Btn
                css="background:#FFFFFF;color:#1A1A18;border:1px solid #D3D3CF;padding:16px 26px;border-radius:4px;font-size:16px;font-weight:600;font-family:inherit;cursor:pointer"
                hover="border-color:#1A1A18"
                onClick={versEntreprise}
              >
                Je recrute pour mon chantier
              </Btn>
            </div>
            <p style={sx('font-size:13px;color:#6F6F68;margin:20px 0 0')}>{HERO.mentions}</p>
          </div>

          <div style={sx(CARD + ';padding:22px')}>
            <div style={sx('display:flex;align-items:center;justify-content:space-between;margin-bottom:16px')}>
              <span style={sx('font-size:13px;font-weight:600;color:#5F5F5A')}>Vos missions correspondantes</span>
              <span style={sx('font-size:12px;color:#6F6F68')}>Lyon · 30 km</span>
            </div>
            {HERO_MISSIONS.map((m) => (
              <div key={m.titre} style={sx('display:flex;align-items:center;gap:14px;padding:14px 0;border-top:1px solid #EDEDEA')}>
                <div style={sx('width:44px;height:44px;border-radius:4px;background:#F1F1EE;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:600;color:#1A1A18;flex:0 0 auto')}>
                  {scoreMission(parId[m.missionId], PROFIL_DEFAUT) + '%'}
                </div>
                <div style={sx('min-width:0;flex:1 1 auto')}>
                  <div style={sx('font-size:15px;font-weight:600')}>{m.titre}</div>
                  <div style={sx('font-size:13px;color:#5F5F5A')}>{m.meta}</div>
                </div>
                <div style={sx('font-size:15px;font-weight:600;white-space:nowrap')}>{m.taux}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Le problème ── */}
      <section style={sx('background:#1A1A18;color:#F6F6F4;padding:76px 24px')}>
        <div style={sx('max-width:1180px;margin:0 auto')}>
          <h2 style={sx('font-size:15px;font-weight:600;color:#F5D90A;margin:0 0 18px')}>Le problème</h2>
          <p style={sx('font-size:34px;line-height:1.25;letter-spacing:-0.015em;font-weight:600;margin:0 0 52px;max-width:20em;text-wrap:pretty')}>
            Le BTP est le secteur qui recourt le plus à l&apos;intérim — et celui où la mise en relation reste la plus
            artisanale.
          </p>
          <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr));gap:1px;background:#35352F;border:1px solid #35352F;border-radius:4px;overflow:hidden')}>
            {CHIFFRES.map((c) => (
              <div key={c.valeur} style={sx('background:#1A1A18;padding:28px 24px')}>
                <div style={sx('font-size:42px;font-weight:600;letter-spacing:-0.02em;line-height:1;margin-bottom:10px')}>{c.valeur}</div>
                <div style={sx('font-size:14px;line-height:1.45;color:#9A9A94')}>{c.label}</div>
              </div>
            ))}
          </div>
          <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px;margin-top:20px')}>
            {[
              { titre: 'Côté intérimaire', items: FRICTIONS_INTERIMAIRE },
              { titre: 'Côté entreprise', items: FRICTIONS_ENTREPRISE },
            ].map((bloc) => (
              <div key={bloc.titre} style={sx('background:#222220;border-radius:4px;padding:28px')}>
                <div style={sx('font-size:13px;font-weight:600;color:#F5D90A;margin-bottom:14px')}>{bloc.titre}</div>
                <ul style={sx('margin:0;padding-left:18px;font-size:15px;line-height:1.75;color:#DCDCD8')}>
                  {bloc.items.map((t) => (
                    <li key={t}>{t}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Comment ça marche ── */}
      <section style={sx('max-width:1180px;margin:0 auto;padding:76px 24px')}>
        <h2 style={sx(EYEBROW_SECTION)}>Comment ça marche</h2>
        <p style={sx('font-size:32px;line-height:1.2;letter-spacing:-0.015em;font-weight:600;margin:0 0 44px;max-width:18em')}>
          Deux parcours, un seul moteur de matching.
        </p>
        <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px')}>
          {[
            { titre: 'Vous êtes intérimaire', etapes: ETAPES_INTERIMAIRE },
            { titre: 'Vous recrutez', etapes: ETAPES_ENTREPRISE },
          ].map((col) => (
            <div key={col.titre} style={sx(CARD + ';padding:30px')}>
              <div style={sx('font-size:17px;font-weight:600;margin-bottom:22px')}>{col.titre}</div>
              {col.etapes.map((e) => (
                <div key={e.n} style={sx('display:flex;gap:16px;padding:14px 0;border-top:1px solid #EDEDEA')}>
                  <div style={sx('width:28px;height:28px;border-radius:4px;background:#1A1A18;color:#FFFFFF;font-size:14px;font-weight:600;display:flex;align-items:center;justify-content:center;flex:0 0 auto')}>
                    {e.n}
                  </div>
                  <div>
                    <div style={sx('font-size:16px;font-weight:600;margin-bottom:4px')}>{e.titre}</div>
                    <div style={sx('font-size:14px;line-height:1.55;color:#5F5F5A')}>{e.texte}</div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* ── Fonctionnalités ── */}
      <section style={sx(SECTION)}>
        <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:16px')}>
          {FONCTIONNALITES.map((f) => (
            <div key={f.titre} style={sx(CARD + ';padding:24px')}>
              <div style={sx('font-size:16px;font-weight:600;margin-bottom:8px')}>{f.titre}</div>
              <div style={sx('font-size:14px;line-height:1.55;color:#5F5F5A')}>{f.texte}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Pour les entreprises ── */}
      <section style={sx(SECTION)}>
        <div style={sx(CARD + ';padding:48px 40px')}>
          <h2 style={sx(EYEBROW_SECTION)}>Pour les entreprises</h2>
          <p style={sx('font-size:32px;line-height:1.18;letter-spacing:-0.015em;font-weight:600;margin:0 0 16px;max-width:22em;text-wrap:pretty')}>
            Publiez une fiche de poste, recevez des candidats déjà vérifiés.
          </p>
          <p style={sx('font-size:17px;line-height:1.55;color:#5F5F5A;margin:0 0 40px;max-width:40em')}>
            Vous décrivez le besoin réel du chantier — poste, dates, commune, habilitations exigées, taux horaire.
            Intérimatch classe les intérimaires disponibles par score de compatibilité et ne vous envoie que des profils
            dont les documents sont à jour.
          </p>

          <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:32px 40px;margin-bottom:44px')}>
            {ARG_ENTREPRISE.map((a) => (
              <div key={a.titre}>
                <div style={sx('font-size:17px;font-weight:600;margin-bottom:7px')}>{a.titre}</div>
                <div style={sx('font-size:15px;line-height:1.55;color:#5F5F5A')}>{a.texte}</div>
              </div>
            ))}
          </div>

          <div style={sx('border-top:1px solid #EDEDEA;padding-top:36px;display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:28px;margin-bottom:38px')}>
            {CHIFFRES_ENTREPRISE.map((c) => (
              <div key={c.valeur}>
                <div style={sx('font-size:40px;font-weight:600;letter-spacing:-0.02em;line-height:1;margin-bottom:8px')}>{c.valeur}</div>
                <div style={sx('font-size:14px;line-height:1.45;color:#5F5F5A')}>{c.label}</div>
              </div>
            ))}
          </div>

          <div style={sx('display:flex;flex-wrap:wrap;gap:12px;align-items:center')}>
            <Btn
              css="background:#1A1A18;color:#FFFFFF;border:0;padding:16px 26px;border-radius:4px;font-size:16px;font-weight:600;font-family:inherit;cursor:pointer"
              hover="background:#333330"
              onClick={versEntreprise}
            >
              Publier une fiche de poste
            </Btn>
            <span style={sx('font-size:14px;color:#6F6F68')}>
              Coefficient de facturation affiché à l&apos;avance. Vous ne payez qu&apos;à la mission pourvue.
            </span>
          </div>
        </div>
      </section>

      {/* ── Témoignages ── */}
      <section style={sx(SECTION)}>
        <h2 style={sx('font-size:15px;font-weight:600;color:#1A1A18;margin:0 0 28px')}>Ils l&apos;utilisent</h2>
        <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px')}>
          {TEMOIGNAGES.map((t) => (
            <figure key={t.nom} style={sx('margin:0;' + CARD + ';padding:28px;display:flex;flex-direction:column;gap:20px')}>
              <blockquote style={sx('margin:0;font-size:17px;line-height:1.5;text-wrap:pretty')}>« {t.citation} »</blockquote>
              <figcaption style={sx('display:flex;align-items:center;gap:12px;margin-top:auto')}>
                <div style={sx('width:36px;height:36px;border-radius:50%;background:#EDEDEA;color:#5F5F5A;font-size:13px;font-weight:600;display:flex;align-items:center;justify-content:center')}>
                  {t.initiales}
                </div>
                <div>
                  <div style={sx('font-size:14px;font-weight:600')}>{t.nom}</div>
                  <div style={sx('font-size:13px;color:#6F6F68')}>{t.role}</div>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* ── Inscription ── */}
      <section id="inscription" style={sx(SECTION)}>
        <div style={sx(CARD + ';padding:48px 40px')}>
          <h2 style={sx('font-size:32px;line-height:1.15;letter-spacing:-0.015em;font-weight:600;margin:0 0 12px')}>
            Créer votre compte
          </h2>
          <p style={sx('font-size:17px;color:#5F5F5A;margin:0 0 34px;max-width:34em')}>
            Deux types de comptes, deux parcours d&apos;inscription. Vos documents sensibles (pièce d&apos;identité, RIB)
            sont chiffrés au repos et en transit.
          </p>
          <div style={sx('display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:18px')}>
            <div style={sx('border:2px solid #1A1A18;border-radius:4px;padding:28px;background:#FAFAF9')}>
              <div style={sx('font-size:19px;font-weight:600;margin-bottom:8px')}>Je cherche des missions</div>
              <div style={sx('font-size:14px;line-height:1.6;color:#5F5F5A;margin-bottom:22px')}>
                Profil, qualifications et disponibilités en 6 minutes. Vous recevez les missions compatibles dès
                validation.
              </div>
              <Btn
                css="width:100%;background:#1A1A18;color:#FFFFFF;border:0;padding:15px;border-radius:4px;font-size:15px;font-weight:600;font-family:inherit;cursor:pointer"
                hover="background:#333330"
                onClick={versInterimaire}
              >
                Créer mon profil intérimaire
              </Btn>
            </div>
            <div style={sx('border:1px solid #D3D3CF;border-radius:4px;padding:28px')}>
              <div style={sx('font-size:19px;font-weight:600;margin-bottom:8px')}>Je recrute</div>
              <div style={sx('font-size:14px;line-height:1.6;color:#5F5F5A;margin-bottom:22px')}>
                SIRET, chantiers, besoins récurrents. Publiez une mission et recevez les profils classés par score de
                compatibilité.
              </div>
              <Btn
                css="width:100%;background:#1A1A18;color:#FFFFFF;border:0;padding:15px;border-radius:4px;font-size:15px;font-weight:600;font-family:inherit;cursor:pointer"
                hover="background:#333330"
                onClick={versEntreprise}
              >
                Créer un compte entreprise
              </Btn>
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section style={sx('max-width:820px;margin:0 auto;padding:0 24px 76px')}>
        <h2 style={sx('font-size:15px;font-weight:600;color:#1A1A18;margin:0 0 24px')}>Questions fréquentes</h2>
        {FAQ.map((f) => (
          <details key={f.q} style={sx(CARD + ';padding:20px 22px;margin-bottom:10px')}>
            <summary style={sx('font-size:16px;font-weight:600;cursor:pointer')}>{f.q}</summary>
            <p style={sx('font-size:15px;line-height:1.6;color:#5F5F5A;margin:12px 0 0;text-wrap:pretty')}>{f.r}</p>
          </details>
        ))}
      </section>

      {/* ── Pied de page ── */}
      <footer style={sx('background:#1A1A18;color:#9A9A94;padding:56px 24px 40px')}>
        <div style={sx('max-width:1180px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:36px')}>
          <div>
            <div style={sx('display:flex;align-items:center;gap:10px;margin-bottom:14px')}>
              <svg width="22" height="22" viewBox="0 0 132 132" aria-hidden="true" style={{ flex: '0 0 auto' }}>
                <rect x="0" y="0" width="132" height="132" rx="4" fill="#F6F6F4" />
                <path d="M28 30 h30 v14 h-16 v44 h16 v14 h-30 z" fill="#1A1A18" />
                <path d="M104 30 h-30 v14 h16 v44 h-16 v14 h30 z" fill="#C9A800" />
              </svg>
              <span style={sx('font-size:17px;font-weight:600;color:#F6F6F4')}>Intérimatch</span>
            </div>
            <p style={sx('font-size:14px;line-height:1.6;margin:0')}>{PIED.baseline}</p>
          </div>
          {PIED.colonnes.map((col) => (
            <div key={col.titre}>
              <div style={sx('font-size:13px;font-weight:600;color:#F6F6F4;margin-bottom:14px')}>{col.titre}</div>
              <p style={sx('font-size:14px;line-height:1.8;margin:0')}>
                {col.lignes.map((l, i) => (
                  <span key={l}>
                    {l}
                    {i < col.lignes.length - 1 && <br />}
                  </span>
                ))}
              </p>
            </div>
          ))}
        </div>
      </footer>
    </main>
  );
}
